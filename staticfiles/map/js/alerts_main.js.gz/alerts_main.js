$(document).ready(function() {
    $('#alerts > div > div').css({
        // padding: '0',
        // height: '',
        // display: 'none',
        padding: '0',
        height: '100%',
    });
    // $('iframe').css({
    //     positon: absolute,
    //     left: '0',
    //     right: '0',
    //     top: '0',
    //     bottom: '0',
    //     // height: '',
    // });
});
